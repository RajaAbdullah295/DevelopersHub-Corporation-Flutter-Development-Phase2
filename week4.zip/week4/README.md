# API Integration & Networking — Flutter Demo

A Flutter app built for **Week 4: API Integration and Networking**. It fetches data from the free [JSONPlaceholder](https://jsonplaceholder.typicode.com/) REST API, parses the JSON, and renders it with proper loading and error states.

## Features

| Task | What it covers | Where |
|---|---|---|
| 1. HTTP requests & JSON parsing | `http` package GET request, JSON decoding into Dart models, results shown in a `ListView` | `lib/screens/post_list_screen.dart` |
| 2. User profile screen | Fetches a single user, displays name, email, and a profile picture, with a menu to switch between the 10 sample users | `lib/screens/user_profile_screen.dart` |
| 3. Error handling & loading indicators | `CircularProgressIndicator` while loading, friendly error messages with a **Retry** button on failure (timeouts, no connection, bad status codes) | `lib/widgets/error_view.dart`, `lib/services/api_service.dart` |

## Project structure

```
lib/
├── main.dart                     # App entry point + bottom nav shell
├── models/
│   ├── post.dart                 # Post model + fromJson
│   └── user.dart                 # User model + fromJson
├── services/
│   └── api_service.dart          # All network calls + error handling
├── screens/
│   ├── post_list_screen.dart     # Task 1: ListView of posts
│   └── user_profile_screen.dart  # Task 2: profile details + picture
└── widgets/
    └── error_view.dart           # Shared error UI with retry button
```

## API endpoints used

- `GET https://jsonplaceholder.typicode.com/posts` — list of posts
- `GET https://jsonplaceholder.typicode.com/users/{id}` — single user
- `GET https://jsonplaceholder.typicode.com/users` — all users

Profile pictures aren't part of JSONPlaceholder's data, so each user's avatar is generated deterministically from their id using [pravatar.cc](https://pravatar.cc).

## Error handling approach

`ApiService` wraps every request in a `try/catch` that distinguishes between:

- **No connection** (`SocketException`) → "No internet connection..."
- **Timeout** (10s, via `.timeout()`) → surfaces as a caught exception with a clear message
- **Non-200 status codes** → "Server returned an error (status ...)"
- **Malformed JSON** (`FormatException`) → "Received an unexpected response..."

All of these are normalized into a single `ApiException` so the UI layer only ever has to handle one exception type and show `ErrorView`, which includes a **Retry** button that re-runs the failed request.

## Getting started

### Prerequisites
- [Flutter SDK](https://docs.flutter.dev/get-started/install) (3.x or later)
- An editor such as VS Code or Android Studio with the Flutter plugin

### Setup

```bash
git clone <this-repo-url>
cd api_networking_app

# This repo ships only the lib/ Dart code. Generate platform folders with:
flutter create .

flutter pub get
flutter run
```

### Testing error handling manually
- Turn off your device/emulator's network connection and reload the Posts or Profile tab to see the error state and Retry button.
- Airplane mode + retry is the fastest way to confirm the loading → error → retry → success cycle works end to end.

## Dependencies

- [`http`](https://pub.dev/packages/http) — REST API requests
- Flutter Material 3 widgets — `CircularProgressIndicator`, `ListView`, `RefreshIndicator`, `NavigationBar`

## Screens

1. **Posts** (default tab) — pull-to-refresh list of all posts from the API, tap a post to see the full body in a bottom sheet.
2. **Profile** — shows the currently selected user's avatar, name, username, email, phone, website, city, and company. Use the person-search icon in the app bar to switch between users 1–10.

## License

MIT — free to use for coursework or as a starting point for your own projects.
