# Task Manager App — Provider State Management (Week 6)

A Flutter Task Management app refactored from `setState` to the **Provider**
package for state management, with real-time UI updates, CRUD operations,
and basic UI/UX animations.

## Learning Objectives Covered

- Applied state management using the `Provider` package (`ChangeNotifier` + `ChangeNotifierProvider`).
- Improved architecture by separating **data (Task model)**, **state/logic (TaskProvider)**, and **UI (screens/widgets)**.
- Used `Selector` / `context.select` to scope widget rebuilds for performance instead of rebuilding the whole tree on every change.
- Added animations: swipe-to-delete, completion checkmark transition, animated progress bar, animated text strike-through.

## Project Structure

```
lib/
├── main.dart                     # App entry point, wires ChangeNotifierProvider at the root
├── models/
│   └── task.dart                 # Task data model + TaskPriority enum
├── providers/
│   └── task_provider.dart        # ChangeNotifier holding all task state + CRUD logic
├── screens/
│   └── home_screen.dart          # Main screen: progress header, filter chips, task list, FAB
└── widgets/
    ├── task_tile.dart            # Single task row (toggle, edit, swipe-to-delete)
    ├── add_edit_task_sheet.dart  # Bottom sheet form used for both Add and Edit
    └── priority_badge.dart       # Small colored priority indicator
```

## Why Provider Instead of setState

| Before (`setState`) | After (`Provider`) |
|---|---|
| Task list lived inside a single `StatefulWidget`, so any change re-rendered the entire screen. | Task list lives in `TaskProvider` (a `ChangeNotifier`), completely decoupled from the UI. |
| Passing data/callbacks down through constructors ("prop drilling") to reach nested widgets. | Any widget can read state with `context.watch`/`context.read`/`Selector` regardless of nesting depth. |
| No easy way to limit rebuilds to only the widgets that actually changed. | `Selector`/`context.select` rebuild only the specific widget subtree that depends on the changed value (see Performance section). |
| Business logic (add/delete/update) mixed into widget code. | Business logic isolated in `TaskProvider`, making it independently testable. |

## State Management Design

`TaskProvider` (in `lib/providers/task_provider.dart`) is the single source
of truth:

- `addTask()`, `updateTask()`, `deleteTask()`, `toggleComplete()` mutate the
  internal task list and call `notifyListeners()`.
- `tasks` getter returns a **filtered** view (All / Active / Completed)
  without ever exposing the mutable list directly.
- Derived values (`completedCount`, `progress`, etc.) are computed getters,
  not stored/duplicated state — a single source of truth avoids sync bugs.

It's registered once at the app root in `main.dart`:

```dart
ChangeNotifierProvider(
  create: (_) => TaskProvider(),
  child: MaterialApp(...),
)
```

## Performance Best Practices Applied

1. **Scoped rebuilds with `Selector`/`context.select`** — e.g. the AppBar's
   "clear completed" button only rebuilds when `completedCount` changes; the
   progress bar only rebuilds when its 3 relevant numbers change; the task
   list only rebuilds when the filtered list changes. The `AppBar` title and
   `FloatingActionButton` never rebuild at all.
2. **`ValueKey` per list item** (`ListView.builder` + `TaskTile(key: ValueKey(task.id))`)
   so Flutter's element diffing reuses widgets instead of rebuilding the
   entire list on every keystroke/toggle.
3. **`const` constructors** used wherever a widget has no dynamic data
   (filter chip container, empty-state icon, etc.) so Flutter can skip
   rebuilding them entirely.
4. **Business logic kept out of `build()`** — filtering/sorting happens in
   the provider, not recomputed inline in widget trees.

## Animations Added

- **Swipe-to-delete**: `Dismissible` with an animated red background.
- **Completion toggle**: `AnimatedSwitcher` cross-fades/scales between the
  empty circle and check-circle icon.
- **Strike-through text**: `AnimatedDefaultTextStyle` animates the
  text-decoration and color when a task is completed.
- **Progress bar**: `TweenAnimationBuilder` animates the bar smoothly to its
  new value instead of jumping.
- **Card elevation/color**: `AnimatedContainer` smoothly shifts background
  color when a task's completed state changes.

## Getting Started

```bash
flutter pub get
flutter run
```

Requires Flutter 3.x+ (Dart 3.0+). No backend/API required — state is
in-memory via Provider (can be extended with `shared_preferences` or a
database for persistence as a future enhancement).

## Possible Future Enhancements

- Persist tasks locally with `shared_preferences` or `sqflite`.
- Add `ProxyProvider`/`MultiProvider` if a second data source (e.g. user
  settings) is introduced.
- Unit test `TaskProvider` methods directly (no widget tree needed, since
  logic is fully separated from UI).

## Demo Video

A 4–5 minute walkthrough video covering:
1. Project structure and the setState → Provider refactor
2. Live demo: add, edit, complete, filter, and delete tasks
3. Explanation of the performance optimizations (Selector-based rebuilds)
4. Animation walkthrough

*(Record and link your video here before submitting.)*
