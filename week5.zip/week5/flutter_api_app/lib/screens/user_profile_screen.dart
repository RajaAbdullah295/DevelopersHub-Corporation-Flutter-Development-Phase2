import 'package:flutter/material.dart';

import '../models/user.dart';
import '../services/api_service.dart';
import '../widgets/error_view.dart';

/// Task 2: Lets the user pick one of JSONPlaceholder's 10 sample users,
/// fetches that user's data, and displays name, email, and a profile
/// picture. Also demonstrates Task 3's loading/error states.
class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

enum _LoadState { loading, error, success }

class _UserProfileScreenState extends State<UserProfileScreen> {
  final ApiService _apiService = ApiService();

  _LoadState _state = _LoadState.loading;
  User? _user;
  String _errorMessage = '';
  int _currentUserId = 1;

  @override
  void initState() {
    super.initState();
    _loadUser(_currentUserId);
  }

  Future<void> _loadUser(int id) async {
    setState(() {
      _state = _LoadState.loading;
      _currentUserId = id;
    });

    try {
      final user = await _apiService.fetchUser(id);
      setState(() {
        _user = user;
        _state = _LoadState.success;
      });
    } on ApiException catch (e) {
      setState(() {
        _errorMessage = e.message;
        _state = _LoadState.error;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profile'),
        actions: [
          PopupMenuButton<int>(
            tooltip: 'Choose user',
            icon: const Icon(Icons.person_search),
            onSelected: _loadUser,
            itemBuilder: (context) => List.generate(
              10,
              (i) => PopupMenuItem(value: i + 1, child: Text('User ${i + 1}')),
            ),
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    switch (_state) {
      case _LoadState.loading:
        return const Center(child: CircularProgressIndicator());
      case _LoadState.error:
        return ErrorView(
          message: _errorMessage,
          onRetry: () => _loadUser(_currentUserId),
        );
      case _LoadState.success:
        final user = _user!;
        return RefreshIndicator(
          onRefresh: () => _loadUser(_currentUserId),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(24),
            children: [
              Center(
                child: CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.grey.shade200,
                  backgroundImage: NetworkImage(user.avatarUrl),
                  onBackgroundImageError: (_, __) {},
                  child: null,
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Text(
                  user.name,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
              Center(
                child: Text(
                  '@${user.username}',
                  style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                ),
              ),
              const SizedBox(height: 24),
              const Divider(),
              _InfoRow(icon: Icons.email, label: 'Email', value: user.email),
              _InfoRow(icon: Icons.phone, label: 'Phone', value: user.phone),
              _InfoRow(icon: Icons.link, label: 'Website', value: user.website),
              _InfoRow(icon: Icons.location_city, label: 'City', value: user.city),
              _InfoRow(icon: Icons.business, label: 'Company', value: user.companyName),
            ],
          ),
        );
    }
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey.shade700),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                Text(value, style: const TextStyle(fontSize: 15)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
