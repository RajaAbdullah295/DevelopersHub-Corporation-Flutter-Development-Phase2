import 'package:flutter/material.dart';

import '../models/post.dart';
import '../services/api_service.dart';
import '../widgets/error_view.dart';

/// Task 1: fetches posts from JSONPlaceholder, parses the JSON, and
/// displays the result in a ListView. Also demonstrates Task 3's
/// loading/error handling pattern (loading -> error -> success states).
class PostListScreen extends StatefulWidget {
  const PostListScreen({super.key});

  @override
  State<PostListScreen> createState() => _PostListScreenState();
}

enum _LoadState { loading, error, success }

class _PostListScreenState extends State<PostListScreen> {
  final ApiService _apiService = ApiService();

  _LoadState _state = _LoadState.loading;
  List<Post> _posts = [];
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadPosts();
  }

  Future<void> _loadPosts() async {
    setState(() => _state = _LoadState.loading);

    try {
      final posts = await _apiService.fetchPosts();
      setState(() {
        _posts = posts;
        _state = _LoadState.success;
      });
    } on ApiException catch (e) {
      setState(() {
        _errorMessage = e.message;
        _state = _LoadState.error;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Posts')),
      body: RefreshIndicator(
        onRefresh: _loadPosts,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    switch (_state) {
      case _LoadState.loading:
        return const Center(child: CircularProgressIndicator());
      case _LoadState.error:
        return ErrorView(message: _errorMessage, onRetry: _loadPosts);
      case _LoadState.success:
        if (_posts.isEmpty) {
          return const Center(child: Text('No posts found.'));
        }
        return ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: _posts.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, index) {
            final post = _posts[index];
            return ListTile(
              leading: CircleAvatar(child: Text('${post.id}')),
              title: Text(
                post.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                post.body,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              onTap: () => _showPostDetail(context, post),
            );
          },
        );
    }
  }

  void _showPostDetail(BuildContext context, Post post) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(post.title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Text(post.body),
          ],
        ),
      ),
    );
  }
}
