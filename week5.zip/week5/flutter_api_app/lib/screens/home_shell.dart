import 'package:flutter/material.dart';

import 'account/my_account_screen.dart';
import 'post_list_screen.dart';
import 'user_profile_screen.dart';

/// Bottom-navigation shell shown once a user is signed in. Combines
/// Week 4's public-API screens with Week 5's Firebase-backed account tab.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  static const _screens = [
    PostListScreen(),
    UserProfileScreen(),
    MyAccountScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.list_alt), label: 'Posts'),
          NavigationDestination(icon: Icon(Icons.public), label: 'API User'),
          NavigationDestination(icon: Icon(Icons.account_circle), label: 'My Account'),
        ],
      ),
    );
  }
}
