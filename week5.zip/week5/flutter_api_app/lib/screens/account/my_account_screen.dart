import 'package:flutter/material.dart';

import '../../models/app_user.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../widgets/error_view.dart';

/// Task 2 (post-login profile) + Task 3 (Firestore read): shown right
/// after a successful login/signup. Streams the user's profile document
/// from Firestore in real time, so any change made elsewhere (e.g. edited
/// directly in the Firebase console) is reflected here immediately.
class MyAccountScreen extends StatelessWidget {
  const MyAccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = AuthService();
    final firestoreService = FirestoreService();
    final user = authService.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Account'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sign out',
            onPressed: () => authService.signOut(),
          ),
        ],
      ),
      body: user == null
          ? const Center(child: Text('Not signed in.'))
          : StreamBuilder<AppUser?>(
              stream: firestoreService.watchUserProfile(user.uid),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return ErrorView(
                    message: 'Could not load your profile. Please check your connection.',
                    onRetry: () {
                      // StreamBuilder re-subscribes automatically once the
                      // underlying network call succeeds; this button just
                      // gives the user something actionable to tap.
                    },
                  );
                }

                final profile = snapshot.data;
                final displayName = (profile?.name.isNotEmpty ?? false) ? profile!.name : null;
                final displayEmail = profile?.email ?? user.email ?? '';
                final initial = (displayName ?? displayEmail).isNotEmpty
                    ? (displayName ?? displayEmail)[0].toUpperCase()
                    : '?';

                return ListView(
                  padding: const EdgeInsets.all(24),
                  children: [
                    Center(
                      child: CircleAvatar(
                        radius: 48,
                        backgroundColor: Colors.indigo.shade100,
                        child: Text(
                          initial,
                          style: const TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.indigo,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Center(
                      child: Text(
                        displayName ?? 'No name on file',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    Center(
                      child: Text(displayEmail, style: TextStyle(color: Colors.grey.shade600)),
                    ),
                    const SizedBox(height: 32),
                    const Divider(),
                    ListTile(
                      leading: const Icon(Icons.badge_outlined),
                      title: const Text('User ID'),
                      subtitle: Text(user.uid),
                    ),
                    if (profile?.createdAt != null)
                      ListTile(
                        leading: const Icon(Icons.event_outlined),
                        title: const Text('Joined'),
                        subtitle: Text(profile!.createdAt!.toLocal().toString().split('.').first),
                      ),
                    if (profile == null)
                      Padding(
                        padding: const EdgeInsets.only(top: 16),
                        child: Text(
                          'No Firestore profile document found for this account yet.',
                          style: TextStyle(color: Colors.orange.shade800),
                        ),
                      ),
                  ],
                );
              },
            ),
    );
  }
}
