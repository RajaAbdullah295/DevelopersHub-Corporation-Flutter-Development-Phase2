import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../models/post.dart';
import '../models/user.dart';

/// Custom exception so the UI layer can show friendly, specific messages
/// instead of raw exception text.
class ApiException implements Exception {
  final String message;
  ApiException(this.message);

  @override
  String toString() => message;
}

/// Thin wrapper around the http package for talking to JSONPlaceholder.
///
/// Centralizing requests here keeps error handling and JSON decoding out of
/// the widget/UI code, which makes both easier to test and to reuse.
class ApiService {
  static const String _baseUrl = 'https://jsonplaceholder.typicode.com';
  static const Duration _timeout = Duration(seconds: 10);

  /// Fetches all posts and returns them as a list of [Post].
  Future<List<Post>> fetchPosts() async {
    final uri = Uri.parse('$_baseUrl/posts');

    try {
      final response = await http.get(uri).timeout(_timeout);

      if (response.statusCode == 200) {
        final List<dynamic> decoded = jsonDecode(response.body) as List<dynamic>;
        return decoded
            .map((item) => Post.fromJson(item as Map<String, dynamic>))
            .toList();
      } else {
        throw ApiException(
          'Server returned an error (status ${response.statusCode}). Please try again.',
        );
      }
    } on SocketException {
      throw ApiException('No internet connection. Check your network and try again.');
    } on HttpException {
      throw ApiException('Could not reach the server. Please try again.');
    } on FormatException {
      throw ApiException('Received an unexpected response from the server.');
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Something went wrong: $e');
    }
  }

  /// Fetches a single user by id.
  Future<User> fetchUser(int id) async {
    final uri = Uri.parse('$_baseUrl/users/$id');

    try {
      final response = await http.get(uri).timeout(_timeout);

      if (response.statusCode == 200) {
        final Map<String, dynamic> decoded =
            jsonDecode(response.body) as Map<String, dynamic>;
        return User.fromJson(decoded);
      } else if (response.statusCode == 404) {
        throw ApiException('User not found.');
      } else {
        throw ApiException(
          'Server returned an error (status ${response.statusCode}). Please try again.',
        );
      }
    } on SocketException {
      throw ApiException('No internet connection. Check your network and try again.');
    } on HttpException {
      throw ApiException('Could not reach the server. Please try again.');
    } on FormatException {
      throw ApiException('Received an unexpected response from the server.');
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Something went wrong: $e');
    }
  }

  /// Fetches all users, used to build the "pick a user" list on the profile tab.
  Future<List<User>> fetchUsers() async {
    final uri = Uri.parse('$_baseUrl/users');

    try {
      final response = await http.get(uri).timeout(_timeout);

      if (response.statusCode == 200) {
        final List<dynamic> decoded = jsonDecode(response.body) as List<dynamic>;
        return decoded
            .map((item) => User.fromJson(item as Map<String, dynamic>))
            .toList();
      } else {
        throw ApiException(
          'Server returned an error (status ${response.statusCode}). Please try again.',
        );
      }
    } on SocketException {
      throw ApiException('No internet connection. Check your network and try again.');
    } on HttpException {
      throw ApiException('Could not reach the server. Please try again.');
    } on FormatException {
      throw ApiException('Received an unexpected response from the server.');
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Something went wrong: $e');
    }
  }
}
