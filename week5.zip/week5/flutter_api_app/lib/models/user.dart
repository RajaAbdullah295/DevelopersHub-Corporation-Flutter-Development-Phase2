/// Model representing a user from JSONPlaceholder's /users endpoint.
///
/// JSONPlaceholder doesn't return a profile picture URL, so we derive a
/// stable one from the user's id using the pravatar.cc placeholder service.
class User {
  final int id;
  final String name;
  final String username;
  final String email;
  final String phone;
  final String website;
  final String companyName;
  final String city;

  User({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.phone,
    required this.website,
    required this.companyName,
    required this.city,
  });

  String get avatarUrl => 'https://i.pravatar.cc/300?img=${(id % 70) + 1}';

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as int,
      name: json['name'] as String,
      username: json['username'] as String,
      email: json['email'] as String,
      phone: json['phone'] as String,
      website: json['website'] as String,
      companyName: (json['company']?['name'] ?? '') as String,
      city: (json['address']?['city'] ?? '') as String,
    );
  }
}
