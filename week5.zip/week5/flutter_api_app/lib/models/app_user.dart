import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents the profile document we store in Firestore under
/// `users/{uid}` — distinct from the public JSONPlaceholder `User` model
/// used in Week 4. This one holds the signed-in user's own data.
class AppUser {
  final String uid;
  final String name;
  final String email;
  final DateTime? createdAt;

  AppUser({
    required this.uid,
    required this.name,
    required this.email,
    this.createdAt,
  });

  factory AppUser.fromMap(String uid, Map<String, dynamic> map) {
    return AppUser(
      uid: uid,
      name: map['name'] as String? ?? '',
      email: map['email'] as String? ?? '',
      createdAt: (map['createdAt'] as Timestamp?)?.toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }
}
