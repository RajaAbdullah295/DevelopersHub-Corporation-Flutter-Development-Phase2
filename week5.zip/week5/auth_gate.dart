import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../screens/auth/login_screen.dart';
import '../screens/home_shell.dart';
import '../services/auth_service.dart';

/// Task 1/2: the root of the auth workflow. Listens to Firebase's
/// auth-state stream and shows [LoginScreen] when signed out or
/// [HomeShell] (which includes the post-login profile) when signed in.
/// Because everything reacts to the stream, login/signup/logout all just
/// work without any manual `Navigator.push` calls after auth actions.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: AuthService().authStateChanges,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.hasData) {
          return const HomeShell();
        }
        return const LoginScreen();
      },
    );
  }
}
