# Flutter API, Auth & Firestore Demo

A Flutter app built across two coursework weeks:

- **Week 4 — API Integration and Networking:** fetch/parse JSON from a public REST API, display it in a `ListView`, handle loading/error states.
- **Week 5 — Firebase Authentication and Database:** email/password auth, login/signup screens, and a Firestore-backed user profile.

## Features by week

| Week | Task | Where |
|---|---|---|
| 4.1 | HTTP requests & JSON parsing into a `ListView` | `lib/screens/post_list_screen.dart` |
| 4.2 | Public user-profile screen (JSONPlaceholder) | `lib/screens/user_profile_screen.dart` |
| 4.3 | Loading spinners & error handling with retry | `lib/widgets/error_view.dart`, `lib/services/api_service.dart` |
| 5.1 | Firebase project setup, Email/Password auth enabled | see **Firebase setup** below |
| 5.2 | Login/Signup screens, post-login profile screen | `lib/screens/auth/`, `lib/widgets/auth_gate.dart`, `lib/screens/account/my_account_screen.dart` |
| 5.3 | Store & retrieve name/email in Firestore | `lib/services/firestore_service.dart`, `lib/models/app_user.dart` |

## Project structure

```
lib/
├── main.dart                       # Initializes Firebase, launches AuthGate
├── firebase_options.dart           # ⚠️ placeholder — regenerate with `flutterfire configure`
├── models/
│   ├── post.dart                   # Week 4: JSONPlaceholder post
│   ├── user.dart                   # Week 4: JSONPlaceholder public user
│   └── app_user.dart               # Week 5: Firestore user profile (name/email)
├── services/
│   ├── api_service.dart            # Week 4: REST calls + error handling
│   ├── auth_service.dart           # Week 5: FirebaseAuth wrapper
│   └── firestore_service.dart      # Week 5: Firestore reads/writes
├── screens/
│   ├── post_list_screen.dart       # Week 4, Task 1
│   ├── user_profile_screen.dart    # Week 4, Task 2
│   ├── home_shell.dart             # Bottom-nav shell shown once signed in
│   ├── auth/
│   │   ├── login_screen.dart       # Week 5, Task 2
│   │   └── signup_screen.dart      # Week 5, Task 2 + Task 3 (writes profile)
│   └── account/
│       └── my_account_screen.dart  # Week 5, Task 2 + Task 3 (reads profile, real-time)
└── widgets/
    ├── error_view.dart             # Full-screen error state with retry
    ├── error_banner.dart           # Inline form error banner
    └── auth_gate.dart              # Routes to Login or HomeShell based on auth state
```

## How authentication routing works

`AuthGate` (`lib/widgets/auth_gate.dart`) wraps a `StreamBuilder` around `FirebaseAuth.instance.authStateChanges()`:

- **Signed out** → shows `LoginScreen` (with a link to `SignupScreen`)
- **Signed in** → shows `HomeShell`, whose third tab is `MyAccountScreen`

Because everything reacts to that stream, login/signup/logout never need manual `Navigator` calls — the UI just follows the auth state.

## Firebase setup (Task 1)

You'll need a real Firebase project; the `firebase_options.dart` shipped here is a **placeholder** and must be regenerated.

1. **Create a Firebase project** at [console.firebase.google.com](https://console.firebase.google.com).
2. **Install the tooling** (one-time):
   ```bash
   dart pub global activate flutterfire_cli
   npm install -g firebase-tools   # if you don't already have the Firebase CLI
   firebase login
   ```
3. **Generate the platform folders** for this project (they're gitignored and not included here):
   ```bash
   flutter create .
   ```
4. **Connect the app to your Firebase project** — this overwrites the placeholder `lib/firebase_options.dart` with your real config and registers each platform in the Firebase console automatically:
   ```bash
   flutterfire configure
   ```
5. **Enable Email/Password sign-in**: in the Firebase console, go to **Build → Authentication → Sign-in method** and enable **Email/Password**.
6. **Create a Firestore database**: go to **Build → Firestore Database → Create database** (start in production mode).
7. **Apply the security rules** in `firestore.rules` (restricts each user to reading/writing only their own profile document):
   ```bash
   firebase deploy --only firestore:rules
   ```
   or paste the contents of `firestore.rules` directly into the Rules tab in the console.
8. Install packages and run:
   ```bash
   flutter pub get
   flutter run
   ```

## Firestore data model

Each user gets a single document at `users/{uid}`:

```json
{
  "name": "Jane Doe",
  "email": "jane@example.com",
  "createdAt": "<server timestamp>"
}
```

- **Write** happens once, right after `signUp()` succeeds, in `SignupScreen._submit()`.
- **Read** is a live stream (`FirestoreService.watchUserProfile`), so `MyAccountScreen` updates in real time if the document changes — including edits made directly in the Firebase console.

## Error handling

- **Auth errors** (`AuthService`) map Firebase's error codes (`email-already-in-use`, `wrong-password`, `weak-password`, `network-request-failed`, etc.) to plain-language messages shown in an inline `ErrorBanner` on the login/signup forms.
- **Firestore errors** (`FirestoreService`) are wrapped in `FirestoreException` and surfaced via the shared `ErrorView`.
- **API errors** (Week 4, `ApiService`) are unchanged — see the Posts and API User tabs.
- Every async action (sign in, sign up, saving/loading a profile) shows a loading spinner and disables its button while in flight.

## Manual test checklist

- [ ] Sign up with a new email → account is created and you land on `HomeShell` → **My Account** shows your name/email.
- [ ] Sign out → you're returned to the login screen.
- [ ] Log back in with the same credentials → your profile loads from Firestore.
- [ ] Try signing up with an email that's already registered → see the inline error.
- [ ] Try logging in with the wrong password → see the inline error.
- [ ] Turn on airplane mode and try to sign in → see the "no internet connection" message.
- [ ] Edit your `users/{uid}` document directly in the Firebase console while **My Account** is open → the screen updates without a manual refresh (proves the real-time stream).

## Dependencies

- [`firebase_core`](https://pub.dev/packages/firebase_core), [`firebase_auth`](https://pub.dev/packages/firebase_auth), [`cloud_firestore`](https://pub.dev/packages/cloud_firestore)
- [`http`](https://pub.dev/packages/http) (Week 4)
- Flutter Material 3 widgets

## License

MIT — free to use for coursework or as a starting point for your own projects.
