import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/app_user.dart';

class FirestoreException implements Exception {
  final String message;
  FirestoreException(this.message);

  @override
  String toString() => message;
}

/// Handles reading/writing the signed-in user's profile document in
/// Cloud Firestore, at `users/{uid}`.
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _users => _db.collection('users');

  /// Creates (or updates) the profile document for [uid] with the given
  /// name and email. Called right after sign-up.
  Future<void> saveUserProfile({
    required String uid,
    required String name,
    required String email,
  }) async {
    try {
      await _users.doc(uid).set({
        'name': name,
        'email': email,
        'createdAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      throw FirestoreException('Could not save your profile. Please try again.');
    }
  }

  /// One-off fetch of a user's profile document.
  Future<AppUser?> fetchUserProfile(String uid) async {
    try {
      final doc = await _users.doc(uid).get();
      if (!doc.exists || doc.data() == null) return null;
      return AppUser.fromMap(uid, doc.data()!);
    } catch (e) {
      throw FirestoreException('Could not load your profile. Please try again.');
    }
  }

  /// Real-time stream of a user's profile document — updates the UI
  /// automatically if the document changes in Firestore.
  Stream<AppUser?> watchUserProfile(String uid) {
    return _users.doc(uid).snapshots().map((doc) {
      if (!doc.exists || doc.data() == null) return null;
      return AppUser.fromMap(uid, doc.data()!);
    });
  }
}
