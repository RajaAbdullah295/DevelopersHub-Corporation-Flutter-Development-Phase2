import 'package:firebase_auth/firebase_auth.dart';

/// Friendly, UI-ready exception thrown for any auth failure so screens
/// never have to inspect raw FirebaseAuthException codes themselves.
class AuthException implements Exception {
  final String message;
  AuthException(this.message);

  @override
  String toString() => message;
}

/// Thin wrapper around FirebaseAuth's email/password sign-in.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  /// Emits whenever the signed-in user changes (login, logout, app start).
  /// Used by [AuthGate] to decide whether to show the auth flow or the app.
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  User? get currentUser => _auth.currentUser;

  Future<UserCredential> signUp({
    required String email,
    required String password,
  }) async {
    try {
      return await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AuthException(_mapError(e));
    } catch (e) {
      throw AuthException('Could not create your account. Please try again.');
    }
  }

  Future<UserCredential> signIn({
    required String email,
    required String password,
  }) async {
    try {
      return await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AuthException(_mapError(e));
    } catch (e) {
      throw AuthException('Could not sign you in. Please try again.');
    }
  }

  Future<void> signOut() => _auth.signOut();

  /// Converts FirebaseAuth's error codes into messages a user can act on.
  String _mapError(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'An account already exists for that email.';
      case 'invalid-email':
        return 'That email address looks invalid.';
      case 'weak-password':
        return 'Password should be at least 6 characters.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many attempts. Please wait a moment and try again.';
      case 'network-request-failed':
        return 'No internet connection. Please try again.';
      default:
        return e.message ?? 'Authentication failed. Please try again.';
    }
  }
}
